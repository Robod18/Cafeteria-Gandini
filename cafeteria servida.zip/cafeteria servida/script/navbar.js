const navbar = document.getElementById('navbar');

window.addEventListener('scroll', function() {
    if (window.scrollY > 150) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});


const navToggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector(".navlistcontainer");

navToggle.addEventListener("click", () => {
    navMenu.classList.toggle("navlistcontainer_visible");


    if (navMenu.classList.contains("navlistcontainer_visible")) {
        navToggle.setAttribute("aria-label", "Cerrar menú");
    } else {
        navToggle.setAttribute("aria-label", "Abrir menú");
    }
});