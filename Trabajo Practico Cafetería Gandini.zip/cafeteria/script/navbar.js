const navbar = document.getElementById('navbar');

window.addEventListener('scroll', function() {
    if (window.scrollY > 150) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});


const navToggle = document.querySelector(".nav-toggle");
const navMenu = document.querySelector(".navlistcontainer");
const contactanos = document.querySelector('#botoncontactanos')
console.log(contactanos)

navToggle.addEventListener("click", () => {
    navMenu.classList.toggle("navlistcontainer_visible");


    if (navMenu.classList.contains("navlistcontainer_visible")) {
        navToggle.setAttribute("aria-label", "Cerrar menú");
    } else {
        navToggle.setAttribute("aria-label", "Abrir menú");
    }
});


contactanos.addEventListener("click", function (event) {
    console.log(contactanos);
    navToggle.setAttribute("aria-label", "Abrir menú");
    navMenu.classList.toggle("navlistcontainer_visible");
})