document.getElementById("enviarmensaje").addEventListener('click', envio_formulario);

function envio_formulario(event) {
    // Prevenir el envío del formulario
    event.preventDefault();

    // Obtener los valores de los campos
    const nombre = document.querySelector('.formulario input[type="text"][placeholder="Nombre"]').value;
    const email = document.querySelector('.formulario input[type="email"][placeholder="Email"]').value;
    const asunto = document.querySelector('.formulario input[type="text"][placeholder="Asunto"]').value;
    const mensaje = document.querySelector('.formulario input[type="text"][placeholder="Mensaje"]').value;

    // Verificar si todos los campos están llenos
    if (nombre && email && asunto && mensaje) {
        alert("Se ha enviado el formulario correctamente. Gracias por su mensaje.");
        // Enviar el formulario manualmente
        document.querySelector('.formulario').submit(); // Esto recargará la página
    } else {
        alert("Por favor, llena todos los campos.");
    }
}