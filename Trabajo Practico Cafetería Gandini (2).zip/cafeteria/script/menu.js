
const products = document.querySelectorAll('.product');
const categoryTitle = document.getElementById('category-title');
const noResultDiv = document.querySelector('.no-result');
const searchInput = document.querySelector('.search-input');
const searchButton = document.querySelector('.search-button');


// Agregar evento de clic a los enlaces de navegación
document.querySelectorAll('.nav-menu-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();

        searchInput.value = '';
        noResultDiv.style.display = 'none';
        categoryTitle.textContent = this.textContent; 

        
            const category = this.getAttribute('data-category');


            products.forEach(product => {
                if (product.getAttribute('data-category') === category) {
                    product.style.display = 'block';
                } else {
                    product.style.display = 'none';
                }
            });
        });
    });

document.addEventListener('DOMContentLoaded', () => {
    const productosContainer = document.querySelector('#product-list');
    const productosDivs = Array.from(productosContainer.getElementsByClassName('product'));
    
   
    searchButton.addEventListener('click', function() {
        const query = searchInput.value.toLowerCase();
        noResultDiv.style.display = 'none'; 

        categoryTitle.textContent = ''; 

        
        let encontrado = false;
        productosDivs.forEach(productoDiv => {
            const nombre = productoDiv.getAttribute('data-name').toLowerCase();
            if (nombre.includes(query)) {
                productoDiv.style.display = ''; 
                encontrado = true;
            } else {
                productoDiv.style.display = 'none'; 
            }
        });

        
        if (!encontrado) {
            noResultDiv.style.display = 'block';
        }
    });
});


document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
        searchInput.value = ''; 
        noResultDiv.style.display = 'none'; 

        
        if (link.classList.contains('logo')) {
            products.forEach(product => {
                product.style.display = 'block'; 
            });
            categoryTitle.textContent = 'Todos los Productos'; 
        }
    });
});





